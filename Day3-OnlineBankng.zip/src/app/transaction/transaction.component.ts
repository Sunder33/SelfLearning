import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import * as opecData from '../../data/opec.json';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import {MatDialog } from '@angular/material/dialog';
import { EditviewComponent } from './editview/editview.component';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})

export class TransactionComponent implements OnInit, AfterViewInit {

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  transactionData: any;
  tableSource: any = new MatTableDataSource();
  displayedColumns: string[] = ["0", "1", "edit", "delete"];

  constructor(private dialog:MatDialog) {
  }

  ngOnInit() {
    this.transactionData = opecData.dataset.data;
    console.log(this.transactionData);

    this.tableSource.data = this.transactionData;
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.

    this.tableSource.paginator = this.paginator;
    this.tableSource.sort = this.sort;
  }

  openEditDialog(trans:any) {
    console.log("edit transaction",trans);
    //this.dialog.open();

    let dialogRef = this.dialog.open(EditviewComponent, {
      width: '450px',
      data:{
        date:trans[0],
        value:trans[1]
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      console.log(result);
    });

  }

  deleteTransaction(trans){
    console.log("delete transction",trans)
  }
}
