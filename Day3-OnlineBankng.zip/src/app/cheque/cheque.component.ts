import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cheque',
  templateUrl: './cheque.component.html',
  styleUrls: ['./cheque.component.css']
})
export class ChequeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
