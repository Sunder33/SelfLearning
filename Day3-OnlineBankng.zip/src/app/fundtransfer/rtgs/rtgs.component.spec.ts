import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RTGSComponent } from './rtgs.component';

describe('RTGSComponent', () => {
  let component: RTGSComponent;
  let fixture: ComponentFixture<RTGSComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RTGSComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RTGSComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
