
import { Component, OnInit } from '@angular/core';
import { MenuService } from '../service/menu.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  menuItems:Array<MenuItem>;
  constructor( private menuService:MenuService) { 


  }

  ngOnInit() {
    this.menuItems = this.menuService.getMenuItems();

    console.log("Menus items from menu service:",this.menuItems);
  }

}
