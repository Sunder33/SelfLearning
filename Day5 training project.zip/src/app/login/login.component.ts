import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { LoginService } from '../service/login.service';
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';

// OAuth 
/*
import { OAuthService, JwksValidationHandler, AuthConfig } from 'angular-oauth2-oidc';

export const authConfig: AuthConfig = {
  issuer: 'https://dev-990222-admin.okta.com/oauth2/default',
  redirectUri: window.location.origin,
  clientId: "0oa2499ns0g0RpXxf4x6"
};
*/

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: User = new User("", "");
  //user:User = new User("user","password");
  constructor(private loginServiceObj: LoginService, private router: Router, private authService: AuthService
    //, private oauthService: OAuthService
    ) {
/*
    this.oauthService.configure(authConfig);
    this.oauthService.tokenValidationHandler = new JwksValidationHandler();
    this.oauthService.loadDiscoveryDocumentAndTryLogin();
*/
  }
  ngOnInit() {

  }

  /*
  oAuthLogin() {
    //event.preventDefault();
    this.oauthService.initImplicitFlow();
    this.router.navigate(["Home/"]);
  }
  */
  login($event) {
    $event.preventDefault();
    console.log(this.user);
    let user: any = this.user;
    this.loginServiceObj.checkUserExistance(this.user).subscribe(response => {
      console.log("service response: ", response);
      // calling newUser() method to diabling login button
      this.newUser();

      if (response && response.email != null) {
        this.authService.token = response.email;
        if (this.authService.isLoggedIn) {
          this.router.navigate(["/Home"]);
        }
      }
      else
        this.router.navigate(["/Login"]);
    })
  }

  /*
  logout() {
    this.oauthService.logOut();
  }

  get givenName() {
    const claims = this.oauthService.getIdentityClaims();
    if (!claims) {
      return null;
    }
    return claims['name'];
  }
*/  


  newUser() {
    this.user = new User("", "");
  }



}
