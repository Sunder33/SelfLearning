import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrationsuccess',
  templateUrl: './registrationsuccess.component.html',
  styleUrls: ['./registrationsuccess.component.css']
})
export class RegistrationsuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
