import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RTGSComponent } from './rtgs/rtgs.component';
import { NeftComponent } from './neft/neft.component';
import { ImpsComponent } from './imps/imps.component';

// add route path for the fund transfer module routing
const routes: Routes = [
  {
    path: "RTGS",
    component: RTGSComponent
  },
  {
    path: "NEFT",
    component: NeftComponent
  },
  {
    path: "IMPS",
    component: ImpsComponent
  }
];

/*
// 
 importing forChild as this is a child(sub) Module and is being called on lazy loading

imports: [RouterModule.forChild(routes)]
*/
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class FundTransferRoutingModule {

}
