import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RTGSComponent } from './rtgs/rtgs.component';
import { NeftComponent } from './neft/neft.component';
import { ImpsComponent } from './imps/imps.component';
import { FundTransferRoutingModule } from './fundtransfer-routing.module';



@NgModule({
  declarations: [RTGSComponent, NeftComponent, ImpsComponent],
  imports: [
    CommonModule,
    FundTransferRoutingModule
  ]
})

export class FundtransferModule { }
