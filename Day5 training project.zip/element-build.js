// onlinebanking is the project name


const fs = require('fs-extra');
const concat = require('concat');
(async function build() {
  const files = [
    './dist/OnlineBanking/runtime-es2015.js',
    './dist/OnlineBanking/polyfills-es2015.js',
    './dist/OnlineBanking/main-es2015.js',
  ]
  await fs.ensureDir('elements')
  await concat(files, 'elements/app-footer.js'); // file name which will have result
  await fs.copyFile('./dist/OnlineBanking/styles.css', 'elements/styles.css')
  await fs.copy('./dist/OnlineBanking/assets/', 'elements/assets/' )
})()
