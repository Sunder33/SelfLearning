import { Injectable } from '@angular/core';
import { Menu } from '../models/menu';
import { menuData } from '../models/menudata';

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor() { }

  getMenuItems=():Array<Menu>=>{
      return menuData;
  }
  
}
