import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';

// add route path
const routes: Routes = [
  {
    path:'Login',
    component:LoginComponent
  },
  {
    path:'Home',
    component:HomeComponent
  },
  {
    path:'', redirectTo:'/Login', pathMatch:'full'
  },
  {
    path:'**', redirectTo:'/Login'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
