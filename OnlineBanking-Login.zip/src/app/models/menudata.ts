import { Menu, SubMenu } from './menu';

export let menuData: Array<Menu> = [
	new Menu("Account Summary", "", "", [new SubMenu("Transactions", "", "")]),

	new Menu("Requests", "", "", [
		new SubMenu("Cheque Request", "", ""),
		new SubMenu("Address Request", "", ""),
	]),

	new Menu("Fund Transfer", "", "", [
		new SubMenu("NEFT", "", ""),
		new SubMenu("RTGS", "", ""),
		new SubMenu("IMPS", "", "")
	])

];
