import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})


export class LoginService {

  constructor(private httpClientObj:HttpClient) { }

checkUserExistance(userobj:any): Observable<any>{
  return this.httpClientObj.get("https://daimalerblog2019-cf.cfapps.io/findboauserbyname/"+userobj.userName);
}

}
