import { Component, OnInit } from '@angular/core';
import {User} from '../models/user';
import { LoginService } from '../service/login.service';
import { AuthService } from '../service/auth.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user:User = new User("","");
  //user:User = new User("user","password");
  constructor(private loginServiceObj:LoginService, private router:Router, private authService:AuthService) { }

  ngOnInit() {

  }

  login($event){
    $event.preventDefault();
    console.log(this.user);
    let user:any= this.user;
    this.loginServiceObj.checkUserExistance(this.user).subscribe(response=>{
      console.log("service response: ",response);
      // calling newUser() method to diabling login button
      this.newUser(); 

      if(response && response.email!=null){
        this.authService.token=response.email;
        if(this.authService.isLoggedIn){
          this.router.navigate(["/Home"]); 
        }
      }
      else
        this.router.navigate(["/Login"]);
    })
  }
 
  newUser() {
    this.user = new User("","");
  }
  
}
