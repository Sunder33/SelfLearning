import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';

import { MatFormFieldModule} from '@angular/material/form-field'
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginService } from './service/login.service';
import { AuthService } from './service/auth.service';
import { UserService } from './service/user.service';
import { MenuService } from './service/menu.service';
import { HomeComponent } from './home/home.component';

import { TieredMenuModule } from 'primeng/tieredmenu';
import { AccountsummaryComponent } from './accountsummary/accountsummary.component';
import { TransactionComponent } from './transaction/transaction.component';
import { RequestComponent } from './request/request.component';
import { ChequeComponent } from './cheque/cheque.component';
import { AddressComponent } from './address/address.component';
import { MatTableModule} from '@angular/material/table';
import { MatPaginatorModule} from '@angular/material/paginator';
import { MatSortModule} from '@angular/material/sort';
import { MatDialogModule} from '@angular/material/dialog';
import { EditComponent } from './transaction/edit/edit.component';
import { EditviewComponent } from './transaction/editview/editview.component';
import { FooterComponent } from './footer/footer.component';

import {createCustomElement} from '@angular/elements';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    AccountsummaryComponent,
    TransactionComponent,
    RequestComponent,
    ChequeComponent,
    AddressComponent,
    EditComponent,
    EditviewComponent,
    FooterComponent
    ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'serverApp' }),
    AppRoutingModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatButtonModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    TieredMenuModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })
  ],
  providers: [LoginService, AuthService, UserService,MenuService
     ,{provide:LocationStrategy,useClass:HashLocationStrategy}
  ],
  entryComponents: [EditComponent,EditviewComponent
    //,FooterComponent
  ],
  bootstrap: [AppComponent]
})

export class AppModule { 

  constructor(private injector:Injector){
/*
    const customFooterElement = createCustomElement(FooterComponent, {injector});

    customElements.define('boa-footer',customFooterElement);
    */
  }

  ngDoBootstrap(){

  }

}

