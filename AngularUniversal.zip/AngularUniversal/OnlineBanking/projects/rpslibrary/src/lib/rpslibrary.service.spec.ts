import { TestBed } from '@angular/core/testing';

import { RpslibraryService } from './rpslibrary.service';

describe('RpslibraryService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RpslibraryService = TestBed.get(RpslibraryService);
    expect(service).toBeTruthy();
  });
});
