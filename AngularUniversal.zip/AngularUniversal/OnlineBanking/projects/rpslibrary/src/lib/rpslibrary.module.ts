import { NgModule } from '@angular/core';
import { RpslibraryComponent } from './rpslibrary.component';
import { MessageComponent } from './message/message.component';



@NgModule({
  declarations: [RpslibraryComponent, MessageComponent],
  imports: [
  ],
  exports: [RpslibraryComponent]
})
export class RpslibraryModule { }
